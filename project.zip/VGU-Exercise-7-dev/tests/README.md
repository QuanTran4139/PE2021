# Testing

Python3 is required to run the testing scripts. Some libraries are also required and can be installed by running `pip3 install -r requirements.txt`.
