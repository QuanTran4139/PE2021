/* Create test accounts */
CALL AddCredential("admin", "password", @_);
